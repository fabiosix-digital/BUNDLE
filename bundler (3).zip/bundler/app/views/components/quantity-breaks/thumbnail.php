<?php

/**
 * Component: Discount Option Image
 *
 * Required variable:
 * - $discount_option
 * Optional constant:
 * - BDLR_PRO (feature gate)
 */
?>

<?php if (!empty($discount_option->image_url) && defined('BDLR_PRO') && BDLR_PRO) : ?>
    <img class="img_thumbnail" name="bundle_image" width="150px" src="<?php echo esc_url($discount_option->image_url); ?>" alt="<?php echo esc_attr($discount_option->title ?? 'Bundle image'); ?>">
<?php endif; ?>