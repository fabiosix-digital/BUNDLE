<?php

/**
 * Component: Discount Option Title
 *
 * Required variable:
 * - $discount_option
 */
?>

<?php if (!empty($discount_option->title)) : ?>
    <div class="quantity-break__title" data-number="<?php echo esc_attr($discount_option->number_of_products); ?>" data-title="<?php echo esc_attr($discount_option->title); ?>">
        <?php echo esc_html($discount_option->title); ?>
    </div>
<?php endif; ?>