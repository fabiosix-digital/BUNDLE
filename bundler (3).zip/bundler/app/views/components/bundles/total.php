<div class="bdlr-total-block">
    <span class="bdlr-total-text"><?php echo esc_html($total_text); ?></span>
    <div class="bdlr-total-price-and-savings">
        <span class="bdlr-total-price">
            <?php if ($total_sale_price !== $total_regular_price) : ?>
                <p class="bdlr-saving-text"><?php echo esc_html($saving_text); ?></p>
                <span class="bdlr-total-regular-price" value="<?php echo esc_attr($total_regular_price); ?>">
                    <?php echo esc_html(Strip_tags(wc_price($total_regular_price))); ?>
                </span>
            <?php endif; ?>
            <span class="bdlr-total-sale-price" value="<?php echo esc_attr($total_sale_price); ?>">
                <?php echo esc_html(Strip_tags(wc_price($total_sale_price))); ?>
            </span>
        </span>
    </div>
</div>