<div class="bdlr-product-price">
    <?php if ($sale_price !== $regular_price) : ?>
        <span class="product-cprice" name="product_cprice" value="<?php echo esc_attr($regular_price); ?>">
            <?php echo esc_html(Strip_tags(wc_price($regular_price))); ?>
        </span>
    <?php endif; ?>

    <?php if ($sale_price > 0) : ?>
        <span class="product-price" name="product_price" value="<?php echo esc_attr($sale_price); ?>">
            <?php echo esc_html(Strip_tags(wc_price($sale_price))); ?>
        </span>
    <?php else : ?>
        <span class="product-price-free" name="product_price" value="0"><?php echo esc_html($free_gift_text); ?></span>
    <?php endif; ?>
</div>