<div class="bdlr-product-block" data-id="<?php echo esc_attr($block_id); ?>" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_share="<?php echo esc_attr($share); ?>">

    <?php include BDLR_PLUGIN_DIR . 'app/views/components/bundles/image.php'; ?>

    <div class="bdlr-product-details-block">
        <div class="bdlr-product-details-text-container">
            <?php include BDLR_PLUGIN_DIR . 'app/views/components/bundles/title.php'; ?>
            <?php include BDLR_PLUGIN_DIR . 'app/views/components/bundles/price.php'; ?>
        </div>
    </div>
</div>