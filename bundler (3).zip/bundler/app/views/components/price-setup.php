<?php

/**
 * Component: Price Setup Logic
 *
 * Required variables:
 * - $discount_option
 * - $initial_price
 * - $product
 * - $offer
 *
 * Sets:
 * - $sale_price
 * - $regular_price
 * - $prices_in_currencies
 * - $ppu
 * - $price_per_unit (optional)
 * - $price_per_unit_text (optional)
 */

use Bundler\Helpers\CartHelper;

$discount_option_price = $initial_price * $discount_option->number_of_products;
$sale_price = $regular_price = $discount_option_price;
$prices_in_currencies = [];

if ($discount_option->discount_type === 'discount') {
    if ($discount_option->discount_method === 'percent_off') {
        $sale_price = $discount_option_price * (1 - $discount_option->discount_value / 100);
    } else if ($discount_option->discount_method === 'value_off') {
        $sale_price = $discount_option_price - $discount_option->discount_value;
    }

    $prices_in_currencies = CartHelper::get_price_in_all_currencies($sale_price, $regular_price);

    $sale_price    = CartHelper::get_wmc_price($sale_price);
    $regular_price = CartHelper::get_wmc_price($regular_price);
} else if (!$discount_option->discount_type || $discount_option->discount_type === 'fixed_price') {

    if ($discount_option->sale_price) {
        $sale_price = $discount_option->sale_price;
        if (wc_tax_enabled()) {
            $sale_price = wc_get_price_to_display($product, ['price' => $sale_price]);
        }
    }
    if ($discount_option->regular_price && $discount_option->regular_price != '') {
        $regular_price = $discount_option->regular_price;
        if (wc_tax_enabled()) {
            $regular_price = wc_get_price_to_display($product, ['price' => $regular_price]);
        }
    }

    $prices_in_currencies = CartHelper::get_price_in_all_currencies($sale_price, $regular_price);

    $sale_price    = CartHelper::get_wmc_price($sale_price);
    $regular_price = CartHelper::get_wmc_price($regular_price);
}

$ppu = $discount_option->show_price_per_unit && $discount_option->show_price_per_unit == 'on';
if ($ppu) {
    $price_per_unit = $sale_price / $discount_option->number_of_products;
    $price_per_unit_text = $discount_option->price_per_unit_text ? $discount_option->price_per_unit_text : '/ unit';
}
