<?php

/**
 * Component: Message Text (blinking or not)
 *
 * Required variables:
 * - $discount_option
 */
?>

<?php if (!empty($discount_option->message) && $discount_option->add_messages === 'on') : ?>
    <?php $effect_class = $discount_option->message_effect === 'blinking'
        ? 'bundle-message-blink'
        : 'bundle-message-not-blink'; ?>
    <div class="<?php echo esc_attr($effect_class); ?>">
        <?php echo esc_html($discount_option->message); ?>
    </div>
<?php endif; ?>