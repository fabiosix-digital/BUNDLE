<?php

/** Expected from caller:
 * $products (WC_Product[])          // N products
 * $regular_prices (float[])         // per product
 * $sale_prices (float[])            // per product
 * $total_regular_price (float)
 * $total_sale_price (float)
 * $offer (object)                   
 * $button_text (string)
 * $free_gift_text (string)
 * $total_text (string)
 */

?>
<div class="bdlr-bundle-container">
    <div class="bdlr-product-wrap">
        <?php foreach ($products as $i => $product) : ?>
            <?php
            $sale_price    = (float)$sale_prices[$i];
            $regular_price = (float)$regular_prices[$i];
            $share         = ($total_sale_price > 0) ? ($sale_price / $total_sale_price) : 0;
            $block_id      = $i;
            ?>
            <?php include BDLR_PLUGIN_DIR . 'app/views/components/bundles/block.php'; ?>
            <?php if ($i < count($products) - 1) : ?>
                <?php include BDLR_PLUGIN_DIR . 'app/views/components/bundles/add-block.php'; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    <?php include BDLR_PLUGIN_DIR . 'app/views/components/bundles/total.php'; ?>
</div>
<div class="bdlr-button-container">
    <div class="bdlr-button">
        <div class="bdlr-button-text"><?php echo esc_html($button_text); ?></div>
    </div>
</div>