<div class="quantity-breaks__vertical">

    <?php
    foreach ($discount_options as $discount_option) {

        include BDLR_PLUGIN_DIR . 'app/views/components/quantity-breaks/price-setup.php';
    ?>

        <div class="quantity-break" data-products_number="<?php esc_attr_e($discount_option->number_of_products); ?>" data-bundle_id="<?php echo esc_attr($product_id) . '-' . esc_attr($discount_option->id); ?>" data-discount_type="<?php esc_attr_e($discount_option->discount_type); ?>" <?php if ($discount_option->discount_type == 'discount') {
                                                                                                                                                                                                                                                                                                ?> data-discount_method="<?php esc_attr_e($discount_option->discount_method); ?>" data-discount_value="<?php esc_attr_e($discount_option->discount_value); ?>" <?php } ?> data-sale_price="<?php esc_attr_e($sale_price); ?>" data-regular_price="<?php esc_attr_e($regular_price); ?>" data-currency_prices="<?php echo esc_attr(json_encode($prices_in_currencies)); ?>">
            <div class="quantity-break__wrapper">

                <?php include BDLR_PLUGIN_DIR . 'app/views/components/quantity-breaks/message.php'; ?>

                <div class="quantity-break__main">

                    <?php include BDLR_PLUGIN_DIR . 'app/views/components/quantity-breaks/radio.php'; ?>

                    <?php include BDLR_PLUGIN_DIR . 'app/views/components/quantity-breaks/thumbnail.php'; ?>

                    <div class="quantity-break__content">

                        <?php include BDLR_PLUGIN_DIR . 'app/views/components/quantity-breaks/title.php'; ?>

                        <?php include BDLR_PLUGIN_DIR . 'app/views/components/price.php'; ?>

                    </div>
                </div>
            </div>

            <?php include BDLR_PLUGIN_DIR . 'app/views/components/quantity-breaks/discount-rule.php'; ?>

        </div>
    <?php }
    ?>
</div>