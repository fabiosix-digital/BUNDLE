<?php

/**
 * Widget that will be displayed in the frontend
 *
 * @since 1.2.7
 */

namespace Bundler\Views;

use Bundler\Controllers\OfferController;
use Bundler\Controllers\SettingsController;
use Bundler\Includes\Traits\Instance;
use Bundler\Helpers\ProductHelper;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Widget
{
    use Instance;

    public function __construct()
    {
        add_action('woocommerce_before_add_to_cart_button', array(__CLASS__, 'display_widget'));

        add_shortcode('bundler_widget', function ($atts) {
            $default = array(
                'offer'             => 0,
                'product'           => 0,
                'template'          => 'classic',
                'hide_default_form' => 'yes',
                'cart_redirect'     => 'off',
                'checkout_redirect' => 'off'
            );
            $params = shortcode_atts($default, $atts);

            return self::display_widget($params);
        });

        add_action('woocommerce_after_add_to_cart_form', array(__CLASS__, 'display_bundle_widget'));

        add_shortcode('bundler_bundle_widget', function ($atts) {
            $default = array(
                'product'           => '#',
                'cart_redirect'     => 'off',
                'checkout_redirect' => 'off'
            );
            $params = shortcode_atts($default, $atts);

            return self::display_bundle_widget($params);
        });
    }

    /**
     * Display bundler widget in the frontend
     * 
     * @param array $params
     * 
     * @return void
     */
    public static function display_widget($params = [])
    {
        $settings = SettingsController::get_instance()->get_quantity_breaks_settings();
        if (!$settings || empty($settings)) $settings = SettingsController::get_instance()->get_default_quantity_breaks_settings();

        $shortcode = false;
        $hide_default_form = true;

        if ($params && is_array($params) && !empty($params)) {
            $shortcode         = true;
            $offer_id          = isset($params['offer']) ? absint($params['offer']) : 0;
            $product_id        = isset($params['product']) ? absint($params['product']) : 0;
            $cart_redirect     = $params['cart_redirect'];
            $checkout_redirect = $params['checkout_redirect'];
        } else {
            global $post;
            if (get_post_type($post) === 'product' && !is_a($post, 'WC_Product')) {
                $product_id        = get_the_ID();
                $cart_redirect     = $settings->cart_redirect;
                $checkout_redirect = $settings->checkout_redirect;
            }
        }

        // $product_id = ProductHelper::resolve_product_id_from_context($product_id);

        $product = wc_get_product($product_id);
        if (!$product) return;

        if ($product->is_type('simple') || $product->is_type('subscription')) {

            $offer_controller = OfferController::get_instance();
            $offer_data = $offer_controller->get_the_offer($product_id);

            if (isset($offer_data)) {
                if ($offer_data['status']) {
                    $offer            = $offer_data['offer']['offerDetails'];
                    $discount_options = $offer_data['offer']['discountOptions'];

                    if ($discount_options && is_array($discount_options)) {

                        $template          = $offer->style;
                        $template_mobile   = $offer->style_mobile;

                        add_filter('woocommerce_product_single_add_to_cart_text', [__CLASS__, 'bdlr_custom_add_to_cart_text'], 10, 2);

                        if ($shortcode) {
                            ob_start();
                        }
?>
                        <div class="wbdl_widget" data-product_id="<?php esc_attr_e($product_id); ?>">
                            <style>
                                table.variations {
                                    display: none !important;
                                }

                                <?php
                                if ($settings->qty_selector == 'off') {
                                ?>.woocommerce .product button.single_add_to_cart_button {
                                    height: 70px !important;
                                    width: 100% !important;
                                    margin-left: 0 !important;
                                }

                                @media (max-width: 1024px) {
                                    .summary-inner .single_add_to_cart_button.button.alt {
                                        height: 70px !important;
                                        width: 100% !important;
                                        margin-left: 0 !important;
                                    }
                                }

                                .woocommerce .product .quantity {
                                    display: none !important;
                                }

                                <?php
                                }
                                ?><?php if ($settings->radio_show === 'off') { ?>.quantity-break .quantity-break__radio input[type=radio] {
                                    display: none;
                                }

                                .quantity-break .quantity-break__radio {
                                    min-width: 25px;
                                }

                                <?php } ?>
                            </style>

                            <tbody>
                                <input type="hidden" name="bdlr_nonce" value="<?php echo wp_create_nonce('bundler'); ?>">
                                <input type="hidden" class="productType" name="wbdl_product_type" value="<?php esc_attr_e($product->get_type()); ?>">
                                <input type="hidden" class="productId" name="product_id" value="<?php esc_attr_e($product_id); ?>">

                                <div class="offer-header">
                                    <?php if ($offer->header && $offer->header !== '') {
                                        esc_html_e($offer->header);
                                    } else {
                                        if ($settings->header_show === 'on') {
                                            esc_html_e($settings->header_text);
                                        }
                                    } ?>
                                </div>

                                <?php
                                if (wc_tax_enabled()) {
                                    $initial_price = wc_get_price_to_display($product);
                                } else {
                                    $initial_price = $product->get_price();
                                }
                                if (function_exists('wp_is_mobile') && wp_is_mobile() && !$shortcode) { // Mobile device
                                    if ($template_mobile === 'vertical') {
                                        include BDLR_PLUGIN_DIR . 'app/views/templates/vertical.php';
                                    } else {
                                        include BDLR_PLUGIN_DIR . 'app/views/templates/classic.php';
                                    }
                                } else { // Desktop
                                    if ($template === 'vertical') {
                                        include BDLR_PLUGIN_DIR . 'app/views/templates/vertical.php';
                                    } else {
                                        include BDLR_PLUGIN_DIR . 'app/views/templates/classic.php';
                                    }
                                }
                                ?>
                            </tbody>
                        </div>
                    <?php
                        if ($shortcode) {
                            $output = ob_get_clean();
                            return $output;
                        }
                    }
                }
            }
        }
    }

    /**
     * Display bundler widget in the frontend
     * 
     * @param array $params
     * 
     * @return void
     */
    public static function display_bundle_widget($params = [])
    {
        $bundle_settings = SettingsController::get_instance()->get_bundle_settings();
        if (!$bundle_settings || empty($bundle_settings)) $bundle_settings = SettingsController::get_instance()->get_default_bundle_settings();

        $shortcode = false;

        if ($params && is_array($params) && !empty($params)) {
            $shortcode = true;
            $product_id        = $params['product'];
            $cart_redirect     = $params['cart_redirect'];
            $checkout_redirect = $params['checkout_redirect'];
        } else {
            global $post;
            if (get_post_type($post) === 'product' && !is_a($post, 'WC_Product')) {
                $product_id        = get_the_ID();
                $cart_redirect     = $bundle_settings->cart_redirect;
                $checkout_redirect = $bundle_settings->checkout_redirect;
            }
        }

        $offer_controller = OfferController::get_instance();
        $offer_data = $offer_controller->get_the_bundle($product_id);

        if (isset($offer_data)) {
            if ($offer_data['status']) {
                $offer = $offer_data['offer']['offerDetails'];
                $bundle = $offer_data['offer']['bundle'];

                if (isset($offer) && isset($bundle)) {

                    $product_ids = is_array($offer->product_ids) ? $offer->product_ids : [];
                    $products    = [];
                    foreach ($product_ids as $pid) {
                        $p = wc_get_product($pid);
                        if ($p) $products[] = $p;
                    }
                    if (count($products) < 2) return; // bundle needs at least 2

                    $offer_header = $offer->header && $offer->header !== ''
                        ? $offer->header
                        : (
                            $bundle_settings->title_show == 'on'
                            ? $bundle_settings->bundle_widget_title
                            : false
                        );

                    $discount_type  = $bundle->discount_type;
                    $saving_text    = $bundle_settings->saving_text ? esc_html($bundle_settings->saving_text) : esc_html__("SAVE ", 'bundler');
                    $total_text     = $bundle_settings->total_text ? esc_html($bundle_settings->total_text) : esc_html__("Total", 'bundler');
                    $free_gift_text = $bundle_settings->free_gift_text ? esc_html($bundle_settings->free_gift_text) : esc_html__("FREE", 'bundler');
                    $button_text    = $bundle_settings->button_text ? esc_html($bundle_settings->button_text) : esc_html__("GRAB THIS DEAL", 'bundler');

                    // --- Prices per product ---
                    $regular_prices = [];
                    $sale_prices    = [];
                    foreach ($products as $p) {
                        if (wc_tax_enabled()) {
                            $price = wc_get_price_to_display($p);
                        } else {
                            $price = $p->get_price();
                        }
                        $regular_prices[] = (float)$price;
                        $sale_prices[]    = (float)$price; // start equal, adjust below
                    }

                    $total_regular_price = array_sum($regular_prices);
                    $total_sale_price    = $total_regular_price;

                    if ($discount_type == "add_discount") {
                        $discount_method = $bundle->discount_method;
                        $discount_value = $bundle->discount_value;

                        if ($discount_method == "percent_off") {
                            $saving_text .= " " . $discount_value . '%';
                            $factor = 1 - ($discount_value / 100);
                            foreach ($sale_prices as $i => $sp) {
                                $sale_prices[$i] = $regular_prices[$i] * $factor;
                            }
                        } elseif ($discount_method === "value_off") {
                            $saving_text .= " " . Strip_tags(wc_price($discount_value));
                            if ($total_regular_price > 0) {
                                foreach ($sale_prices as $i => $sp) {
                                    $share = $regular_prices[$i] / $total_regular_price;
                                    $sale_prices[$i] = max(0.0, $regular_prices[$i] - $share * $discount_value);
                                }
                            }
                        }
                        $total_sale_price = array_sum($sale_prices);
                    }

                    if ($shortcode) {
                        ob_start();
                    }
                    ?>

                    <style>
                        div.bdlr_bundle_widget .bdlr-bundle-container {
                            background: <?php esc_html_e($bundle_settings->background_color); ?> !important;
                            border-color: <?php esc_html_e($bundle_settings->border_color); ?> !important;
                        }

                        div.bdlr_bundle_widget .bdlr-product-title {
                            color: <?php esc_html_e($bundle_settings->product_name_color); ?> !important;
                        }

                        div.bdlr_bundle_widget .product-price-free,
                        div.bdlr_bundle_widget div.bdlr-total-price-and-savings .bdlr-saving-text {
                            color: <?php esc_html_e($bundle_settings->saving_color); ?> !important;
                        }

                        div.bdlr_bundle_widget .product-price {
                            color: <?php esc_html_e($bundle_settings->sale_price_color); ?> !important;
                        }

                        div.bdlr_bundle_widget .product-cprice {
                            color: <?php esc_html_e($bundle_settings->regular_price_color); ?> !important;
                        }

                        div.bdlr_bundle_widget div.bdlr-button-container div.bdlr-button {
                            background: <?php esc_html_e($bundle_settings->button_color); ?> !important;
                        }
                    </style>

                    <?php
                    // Build comma-separated ids for a data attribute (useful for JS)
                    $ids_attr = implode(',', array_map(fn ($p) => (int)$p->get_id(), $products));
                    ?>
                    <div class="bdlr_bundle_widget" data-product_ids="<?php echo esc_attr($ids_attr); ?>" data-discount_type="<?php echo esc_attr($bundle->discount_type); ?>" data-discount_value="<?php echo esc_attr($bundle->discount_value); ?>" data-discount_method="<?php echo esc_attr($bundle->discount_method); ?>">
                        <tbody>
                            <input type="hidden" name="bdlr_nonce" value="<?php echo wp_create_nonce('bundler'); ?>">

                            <?php foreach ($products as $idx => $p) : ?>
                                <input type="hidden" class="product_id" name="product_id[]" value="<?php echo esc_attr($p->get_id()); ?>">
                                <input type="hidden" class="productType" name="bdlr_product_type[]" value="<?php echo esc_attr($p->get_type()); ?>">
                            <?php endforeach; ?>

                            <div class="offer-header">
                                <?php if ($offer_header) : ?>
                                    <span></span><span><?php esc_html_e($offer_header); ?></span><span></span>
                                <?php endif; ?>
                            </div>

                            <?php include BDLR_PLUGIN_DIR . 'app/views/templates/bundle.php'; ?>
                        </tbody>
                    </div>
<?php
                    if ($shortcode) {
                        $output = ob_get_clean();
                        return $output;
                    }
                } // endif
            }
        }
    }

    /**
     * Add custom text to the ATC button
     * 
     * @param mixed $text
     * 
     * @return [type]
     */
    public static function bdlr_custom_add_to_cart_text($text)
    {
        $settings_controller = SettingsController::get_instance();
        $settings = $settings_controller->get_quantity_breaks_settings() ? $settings_controller->get_quantity_breaks_settings() : $settings_controller->get_default_settings()->quantity_breaks;

        if ($settings->atc_button_show_custom_text === 'on') {
            return $settings->atc_button_custom_text;
        }

        return $text;
    }
}

return Widget::get_instance();
