<?php

/**
 * FOX – Currency Switcher Professional for WooCommerce
 *
 * @see https://wordpress.org/plugins/woocommerce-currency-switcher/
 * 
 * * @since 3.3.4
 * 
 */

namespace Bundler\Integrations;

use Bundler\Controllers\OfferController;

if (!defined('ABSPATH')) exit;

/**
 * FOX_Currency_Switcher class.
 */
if (!class_exists('FOX_Currency_Switcher')) {

    class FOX_Currency_Switcher
    {
        protected $woocs_settings;
        protected $offer_controller;

        public function __construct()
        {
            $this->offer_controller = new OfferController();

            add_filter('wbdl_get_currency_data', array($this, 'woocs_get_currency_data'), 10);
            add_filter('wbdl_get_wmc_price', array($this, 'woocs_get_price'), 10, 3);

            // product price hooks
            add_filter('woocommerce_product_get_price', array($this, 'fox_revert_product_price'), 100, 2);
        }

        /**
         * Get the current currency data
         * 
         * @return array
         */
        public function woocs_get_currency_data()
        {
            $currency_data = [];

            if (class_exists('WOOCS')) {
                global $WOOCS;
                $currencies = $WOOCS->get_currencies();
                $current_currency = $WOOCS->current_currency;
                $default_currency = $WOOCS->default_currency;

                $currency_data = array(
                    'currencies'       => $currencies,
                    'current_currency' => $current_currency,
                    'default_currency' => $default_currency,
                );
            }

            return $currency_data;
        }

        /**
         * Get the price in the current currency
         * 
         * @param mixed $price
         * @param string $wmc_price
         * @param string $is_wmc_custom_price
         * 
         * @return mixed
         */
        public function woocs_get_price($price, $wmc_price = false, $is_wmc_custom_price = 'on')
        {
            if (!$price) return;

            if (class_exists('WOOCS')) {
                global $WOOCS;
                $current_currency = $WOOCS->current_currency;
                $default_currency = $WOOCS->default_currency;

                if ($current_currency != $default_currency) {
                    $price = $WOOCS->convert_from_to_currency($price, $default_currency, $current_currency);
                }
            }

            return $price;
        }

        /**
         * Revert the FOX convert price filter for products
         * 
         * @param mixed $price
         * @param mixed $product
         * 
         * @return mixed
         */
        public function fox_revert_product_price($price, $product)
        {
            if (class_exists('WOOCS')) {
                if (!is_shop() && !is_product_category()) {
                    $product_id = $product->get_id();
                    $discount_options = $this->offer_controller->get_the_discounts_desc($product_id);
                    if ($discount_options && is_array($discount_options)) {
                        global $WOOCS;
                        $currencies = $WOOCS->get_currencies();
                        $current_currency = $WOOCS->current_currency;
                        $default_currency = $WOOCS->default_currency;
                        if ($current_currency != $default_currency) {
                            return $WOOCS->back_convert($price, $currencies[$current_currency]['rate']);
                        }
                    }
                }
            }

            return $price;
        }
    }
}
