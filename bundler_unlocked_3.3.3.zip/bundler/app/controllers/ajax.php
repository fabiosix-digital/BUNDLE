<?php

/**
 * AJAX
 *
 * @since 1.0.0
 * 
 */

namespace Bundler\Controllers;

use Bundler\Helpers\ProductHelper;
use Bundler\Includes\Traits\Instance;

if (!defined('ABSPATH')) exit;

class Ajax
{

    use Instance;

    public function __construct()
    {
        $this->handle_public_ajax();
    }

    /**
     * Add public ajax endpoints
     *
     * @return void
     */
    public function handle_public_ajax()
    {
        $endpoints = self::get_available_public_endpoints();
        foreach ($endpoints as $action => $function) {
            add_action('wc_ajax_' . $action, array($this, $function));
            // add_action('wp_ajax_' . $action, array($this, $function));
            // add_action('wp_ajax_nopriv_' . $action, array($this, $function));
        }
    }

    /**
     * Get public endpoints     
     *
     * @return array
     */
    public function get_available_public_endpoints()
    {
        return [
            'bdlr_add_to_cart'        => 'add_to_cart',
            'bdlr_add_bundle_to_cart' => 'add_bundle_to_cart',
        ];
    }

    /**
     * Get WC public endpoints
     *
     * @param $query
     *
     * @return array
     */
    public function get_public_endpoints($query = [])
    {
        $public_endpoints = $this->get_available_public_endpoints();
        if (empty($public_endpoints) || !is_array($public_endpoints)) {
            return [];
        }

        $endpoints = [];
        foreach ($public_endpoints as $key => $function) {
            $url = \WC_AJAX::get_endpoint($key);
            $url = is_array($query) && count($query) > 0 ? add_query_arg($query, $url) : $url;

            $endpoints[$key] = $url;
        }

        return $endpoints;
    }

    /**
     * Add to cart function for simple and variable products
     * 
     * @return void
     */
    public function add_to_cart()
    {

        $this->verify_nonce();

        $product_id        = apply_filters('woocommerce_add_to_cart_product_id', absint(sanitize_text_field($_POST['product_id'])));
        $products_number   = empty($_POST['products_num']) ? 1 : wc_stock_amount(sanitize_text_field($_POST['products_num']));
        $qty               = isset($_POST['product_quantity']) ? sanitize_text_field($_POST['product_quantity']) : 1;
        $product_status    = get_post_status($product_id);
        $passed_validation = true;

        $product = wc_get_product($product_id);

        $cart_item_meta = array();
        $cart_item_meta['_wbdl_data'] = ['use_custom_variations' => 'off'];
        $cart_item_meta['_wbdl_data']['offer_type'] = 'volume_discount';

        // if (class_exists("EPOW\Frontend\Frontend")) {
        //     $epow_frontend = \EPOW\Frontend\Frontend::instance();
        //     $cart_item_meta = $epow_frontend->epow_add_fields_to_cart_item($cart_item_meta, $product_id, null);
        // }

        if ($product->is_type('simple') || $product->is_type('subscription')) {

            $qty = $qty * $products_number;

            if ($product) $stock_quantity = $product->get_stock_quantity();
            if (!ProductHelper::is_product_in_stock($product_id, $qty)) {
                $passed_validation = false;
            }

            if ($passed_validation && 'publish' === $product_status && WC()->cart->add_to_cart($product_id, $qty, 0, [], $cart_item_meta)) {
                do_action('woocommerce_ajax_added_to_cart', $product_id);
                if ('yes' === get_option('woocommerce_cart_redirect_after_add')) {
                    wc_add_to_cart_message(array($product_id => $qty), true);
                }
                \WC_AJAX::get_refreshed_fragments();
            } else {
                $response = $stock_quantity > 0 ? array(
                    'error'       => true,
                    'message'     => sprintf(
                        /* translators: %d: stock quantity */
                        __('This product has only %d items in stock.', 'bundler'),
                        $stock_quantity
                    ),
                    'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id)
                ) : array(
                    'error'       => true,
                    'message'     => __('This product is out of stock.', 'bundler'),
                    'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id)
                );
                wp_send_json($response);
            }
        }
        wp_die();
    }

    /**
     * Add to cart function for bundle offers
     * 
     * @return void
     */
    public function add_bundle_to_cart()
    {
        $this->verify_nonce();

        // Helper to read array-like POST keys both with and without [] suffix.
        $read_array = function (string $key_base): array {
            if (isset($_POST[$key_base]) && is_array($_POST[$key_base])) {
                return (array) $_POST[$key_base];
            }
            $bracket_key = $key_base . '[]';
            if (isset($_POST[$bracket_key]) && is_array($_POST[$bracket_key])) {
                return (array) $_POST[$bracket_key];
            }
            return [];
        };

        // New N-product payload
        $product_ids   = $read_array('product_ids');
        $product_types = $read_array('product_types');
        $var_arrays    = $read_array('var_arrays'); // JSON strings per product

        // Fallback to legacy 2-product fields if no N-product payload
        if (empty($product_ids)) {
            $pid1 = isset($_POST['product_id1']) ? absint(sanitize_text_field($_POST['product_id1'])) : 0;
            $pid2 = isset($_POST['product_id2']) ? absint(sanitize_text_field($_POST['product_id2'])) : 0;

            if ($pid1) $product_ids[] = $pid1;
            if ($pid2) $product_ids[] = $pid2;

            // Infer types by looking up products (keeps behavior consistent with old code)
            foreach ($product_ids as $pid) {
                $p = wc_get_product($pid);
                $product_types[] = $p ? $p->get_type() : 'simple';
            }

            // Legacy var arrays
            $v1 = isset($_POST['var_array1']) ? wp_unslash($_POST['var_array1']) : '';
            $v2 = isset($_POST['var_array2']) ? wp_unslash($_POST['var_array2']) : '';
            if ($v1 !== '') $var_arrays[] = $v1;
            if ($v2 !== '') $var_arrays[] = $v2;
        }

        // Nothing to add?
        if (count($product_ids) < 2) {
            wp_send_json([
                'error'   => true,
                'message' => __('A bundle must include at least two products.', 'bundler'),
            ]);
        }

        $bundle_product_ids = []; // final resolved IDs (product or variation) to add
        $cart_item_meta = [];
        $cart_item_meta['_wbdl_data'] = ['offer_type' => 'bundle'];

        // Validate and resolve each product
        foreach ($product_ids as $i => $pid_raw) {
            $pid = absint($pid_raw);
            if (!$pid) {
                wp_send_json([
                    'error'   => true,
                    'message' => __('Invalid product in bundle.', 'bundler'),
                ]);
            }

            $product = wc_get_product($pid);
            if (!$product) {
                wp_send_json([
                    'error'   => true,
                    'message' => __('A selected product no longer exists.', 'bundler'),
                ]);
            }

            $status = get_post_status($pid);
            if ($status !== 'publish') {
                wp_send_json([
                    'error'   => true,
                    'message' => __('One of the products in the bundle is not purchasable.', 'bundler'),
                ]);
            }

            $type = isset($product_types[$i]) ? sanitize_text_field($product_types[$i]) : $product->get_type();

            if ($type !== 'variable' && !$product->is_type('variable') && $type !== 'variable-subscription' && !$product->is_type('variable-subscription')) {
                if (ProductHelper::is_product_in_stock($pid, 1)) {
                    $bundle_product_ids[] = $pid;
                } else {
                    wp_send_json([
                        'error'   => true,
                        'message' => __('One of the products you have selected is out of stock.', 'bundler'),
                    ]);
                }
            } else {
                return;
            }
        }

        // Add all resolved products to the cart
        foreach ($bundle_product_ids as $resolved_id) {
            WC()->cart->add_to_cart($resolved_id, 1, null, null, $cart_item_meta);
        }

        // Keep WooCommerce behavior
        do_action('woocommerce_ajax_added_to_cart', end($bundle_product_ids));
        if ('yes' === get_option('woocommerce_cart_redirect_after_add')) {
            wc_add_to_cart_message([end($bundle_product_ids) => 1], true);
        }

        \WC_AJAX::get_refreshed_fragments();
        wp_die();
    }

    /**
     * Verify nonce
     *
     * @return void
     */
    public function verify_nonce()
    {
        $nonce = filter_input(INPUT_POST, 'nonce', FILTER_UNSAFE_RAW);
        if (is_null($nonce) || !wp_verify_nonce($nonce, 'bundler')) {
            wp_send_json(array(
                'msg'  => __('Security check failed', 'bundler'),
                'code' => 401
            ));
        }
    }
}

return Ajax::get_instance();
