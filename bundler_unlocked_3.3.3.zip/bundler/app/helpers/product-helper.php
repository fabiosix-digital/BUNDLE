<?php

namespace Bundler\Helpers;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class ProductHelper
{

    /**
     * Check if a product is in stock
     *
     * @param mixed $product_id
     * @param mixed $qty
     * @return bool
     */
    public static function is_product_in_stock($product_id, $qty)
    {
        $product          = wc_get_product($product_id);
        $quantity_in_cart = 0;

        if (WC()->cart) {
            $cart = WC()->cart->cart_contents;
        }
        if ($cart) {
            foreach ($cart as $cart_item) {
                if ($cart_item['product_id'] == $product_id) {
                    $quantity_in_cart++;
                }
            }
        }

        $total_quantity = $qty + $quantity_in_cart;

        return $product && $product->is_in_stock() && $product->has_enough_stock($total_quantity);
    }

    /**
     * Format a product object
     * 
     * @param mixed $product
     * 
     * @return array
     */
    public static function format_product($product)
    {
        $initial_price = 0;
        if ($product->is_type('simple') || $product->is_type('subscription')) {
            $initial_price = $product->get_price();
        }

        $attributes = [];
        foreach ($product->get_attributes() as $attribute) {
            $options = $attribute->is_taxonomy() ? $attribute->get_terms() : $attribute->get_options();
            $formatted_options = array_map(function ($val) use ($attribute) {
                return $attribute->is_taxonomy()
                    ? ['label' => esc_html($val->name), 'value' => $val->slug]
                    : ['label' => esc_html($val), 'value' => esc_attr($val)];
            }, $options);

            $attributes[] = [
                'name' => $attribute->get_name(),
                'slug' => wc_sanitize_taxonomy_name($attribute->get_name()),
                'wooName' => wc_attribute_label($attribute->get_name()),
                'options' => $formatted_options,
                'hasVariation' => $attribute->get_variation(),
                'isTaxonomy' => $attribute->is_taxonomy(),
            ];
        }

        $image_url = wp_get_attachment_image_url($product->get_image_id(), 'full');

        return [
            'id' => $product->get_id(),
            'name' => $product->get_title(),
            'type' => $product->get_type(),
            'initialPrice' => $initial_price,
            'attributes' => $attributes,
            'image' => $image_url,
        ];
    }

    /**
     * Search products
     * 
     * @param mixed $query
     * 
     * @return [type]
     */
    public static function search_products($query, $limit)
    {
        if ($query) {
            remove_all_filters('woocommerce_data_stores');

            $product_query = array(
                'limit'  => $limit,
                'status' => 'publish',
                'type'   => 'simple',
                's'      => $query,
            );
            $products = wc_get_products($product_query);

            $formatted_products = [];

            foreach ($products as $product) {
                $formatted_products[] = ProductHelper::format_product($product);
            }

            return $formatted_products;
        }

        return [];
    }

    public static function get_product_for_preview()
    {
        remove_all_filters('woocommerce_data_stores');

        $product_query = array(
            'limit'  => 1,
            'status' => 'publish',
            'type'   => 'simple',
        );
        $products = wc_get_products($product_query);

        if ($products && !empty($products)) {
            $product = ProductHelper::format_product($products[0]);
            return $product;
        }

        return null;
    }

    public static function resolve_product_id_from_context($maybe_id = 0): int
    {
        $id = absint($maybe_id);
        if ($id) return $id;

        // 1) Woo global on single product pages
        if (isset($GLOBALS['product']) && $GLOBALS['product'] instanceof \WC_Product) {
            return (int) $GLOBALS['product']->get_id();
        }

        // 2) Main queried object
        if (function_exists('get_queried_object_id')) {
            $qid = (int) get_queried_object_id();
            if ($qid && get_post_type($qid) === 'product') return $qid;
        }

        // 3) Classic $post fallback
        global $post;
        if ($post && get_post_type($post) === 'product') return (int) $post->ID;

        // 4) Woo conditional (extra guard)
        if (function_exists('is_product') && is_product()) {
            $pid = (int) get_the_ID();
            if ($pid) return $pid;
        }

        // 5) Elementor editor/preview (best effort)
        if (did_action('elementor/loaded') && class_exists('\Elementor\Plugin')) {
            // Live preview page
            if (\Elementor\Plugin::$instance->preview->is_preview_mode()) {
                $preview_id = (int) \Elementor\Plugin::$instance->preview->get_post_id();
                if ($preview_id && get_post_type($preview_id) === 'product') return $preview_id;
            }
            // Template being rendered with a product context
            if (isset($post->ID) && 'elementor_library' === get_post_type($post->ID)) {
                // If you store a custom preview product id in meta, read it here:
                $preview_product = (int) get_post_meta($post->ID, '_elementor_preview_product_id', true);
                if ($preview_product) return $preview_product;
            }
        }

        // 6) Query var / GET fallback (optional)
        $qv = (int) get_query_var('product_id');
        if ($qv) return $qv;
        if (!empty($_GET['product_id'])) return absint($_GET['product_id']);

        return 0;
    }
}
