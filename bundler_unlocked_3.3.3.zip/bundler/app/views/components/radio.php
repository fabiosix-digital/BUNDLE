<?php

/**
 * Component: Radio Selector
 *
 * Required variable:
 * - $discount_option
 */
?>

<div class="quantity-break__radio <?php echo ($discount_option->preselected_offer === 'on') ? 'active' : ''; ?>">
    <input type="radio" class="radio_select" name="bundle_select" value="1" <?php checked($discount_option->preselected_offer === 'on'); ?>>
</div>