<div class="bdlr-product-image-block">
    <img class="bdlr-product-image" width="100" height="100" src="<?php echo esc_url(wp_get_attachment_image_url($product->get_image_id(), 'full')); ?>" />
</div>