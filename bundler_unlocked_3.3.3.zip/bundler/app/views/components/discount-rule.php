<?php

/**
 * Component: Discount Rule Message
 *
 * Required variables:
 * - $discount_option
 * - $sale_price
 * - $regular_price
 */
?>

<?php if ($discount_option->add_messages === 'on' && !empty($discount_option->discount_rule)) : ?>
    <?php
    $str = $discount_option->discount_rule;

    if (str_contains($str, '($)') || str_contains($str, '(%)')) {
        if ($regular_price && $sale_price) {
            $discount      = $regular_price - $sale_price;
            $percentChange = (1 - $sale_price / $regular_price) * 100;
            $percent       = number_format($percentChange);
            $str = str_replace("($)", wc_price($discount), $str);
            $str = str_replace("(%)", $percent . '%', $str);
        }
    }
    ?>

    <div class="quantity-break__discount-rule">
        <div class="quantity-break__discount-rule__content">
            <?php echo $str; ?>
        </div>
    </div>
<?php endif; ?>