<?php

/**
 * Component: Price Display
 *
 * Variables needed:
 * - $sale_price
 * - $regular_price
 * - $ppu (bool)
 * - $price_per_unit_text (optional)
 * - $number_of_products
 * - $reverse_price_order (optional) → if true: show sale before regular
 */

$show_regular = $regular_price && ($regular_price > $sale_price);
$price_per_unit = $ppu ? ($sale_price / $discount_option->number_of_products) : 0;
$regular_price_per_unit = $ppu ? ($regular_price / $discount_option->number_of_products) : 0;

if (!isset($reverse_price_order)) $reverse_price_order = false;

$price_html_sale = $ppu
    ? '<span class="bundle-price" name="bundle_price" value="' . esc_attr(Strip_tags($sale_price)) . '">' . esc_html(Strip_tags(wc_price($price_per_unit))) . ' ' . esc_html($price_per_unit_text ?? '/ unit') . '</span>'
    : '<span class="bundle-price" name="bundle_price" value="' . esc_attr(Strip_tags($sale_price)) . '">' . esc_html(Strip_tags(wc_price($sale_price))) . '</span>';

$price_html_regular = $show_regular
    ? ($ppu
        ? '<span class="bundle-cprice" name="bundle_cprice" value="' . esc_attr(Strip_tags($regular_price)) . '">' . esc_html(Strip_tags(wc_price($regular_price_per_unit))) . ' ' . esc_html($price_per_unit_text ?? '/ unit') . '</span>'
        : '<span class="bundle-cprice" name="bundle_cprice" value="' . esc_attr(Strip_tags($regular_price)) . '">' . esc_html(Strip_tags(wc_price($regular_price))) . '</span>')
    : '';

echo '<div class="quantity-break__price">';
echo $reverse_price_order ? $price_html_sale . $price_html_regular : $price_html_regular . $price_html_sale;
echo '</div>';
