(function () {
  const { media, price, cart } = Bundler;
  const { updateDisplayedProductPrice, setATCPriceText } = price;
  const { updateOfferImage } = media;
  const { addOfferToCart } = cart;

  var $ = jQuery;

  var $form = $("form.cart");
  var originalATCText = $form.find(".single_add_to_cart_button").first().text();
  const variationData = bdlrData.available_variations;

  jQuery(document).ready(function ($) {
    /**
     * select a bundle offer and unselect the others
     * @param mixed bundle
     * @return void
     */
    function selectOffer($qb) {
      var qbId = $qb.data("bundle_id");

      // get all the qbs with the same id
      var qbs = $(document)
        .find(".wbdl_widget")
        .find("div.quantity-break[data-bundle_id='" + qbId + "']");

      qbs.each(function () {
        var parent = $(this).closest(".wbdl_widget");

        parent.find(".quantity-break").each(function (i, obj) {
          $(obj).removeClass("active");
        });

        $(this).addClass("active");

        parent
          .find("div[class^='quantity-break']:not(.active)")
          .find(".quantity-break__variants")
          .css("display", "none");
        parent
          .find("div[class^='quantity-break']:not(.active)")
          .find(".quantity-break__variant-selector .option2")
          .removeAttr("name");
        parent
          .find("div[class^='quantity-break']:not(.active)")
          .find(
            ".quantity-break__variant-selector .quantity-break__attribute-option"
          )
          .removeAttr("name");

        $(this).find(".quantity-break__variants").css("display", "flex");
        if ($(this).find('.img_thumbnail[src!=""]').length) {
          $(this).find(".quantity-break__attribute-label").css("width", "100%");
        }
        $(this).find(".radio_select").prop("checked", true);
      });

      var regularPrice = $qb.find(".bundle-cprice").attr("value") || 0;
      var salePrice = $qb.find(".bundle-price").attr("value") || 0;

      updateDisplayedProductPrice(salePrice, regularPrice);

      var img = $qb.find(".img_thumbnail").attr("src");
      if (img) {
        if (img.startsWith("data:image")) {
          var img = $qb.find(".img_thumbnail").attr("data-src");
        }
        updateOfferImage(img);
      }

      // Change the add to cart button text (also works when the button has children) (PRO)
      setATCPriceText(originalATCText, salePrice);
    }

    /* Click on the preselected bundle offer */
    $(".wbdl_widget")
      .find("div[class^='quantity-break']:not(.active)")
      .find(".bundle-variation")
      .css("display", "none");
    $(".wbdl_widget")
      .find(".quantity-break__radio.active")
      .each(function (i, obj) {
        setTimeout(function () {
          $(obj).closest("div[class^='quantity-break']").click();
        }, 600);
      });

    /* action after a qb offer is selected */
    $(document).on("click", ".wbdl_widget .quantity-break", function (e) {
      const $qb = $(this);
      if ($qb.hasClass("active")) return;

      $(".single_add_to_cart_button").removeClass("disabled");
      selectOffer($qb);
    });

    /* action after add to cart button is clicked */
    $(document).on("click", ".single_add_to_cart_button", function (e) {
      if ($(this).hasClass("disabled")) return;
      var $atcButton = $(this),
        $form = $atcButton.closest("form.cart");

      var $bundlerWidget = $form.find("div[class='wbdl_widget']").length
        ? $form.find("div[class='wbdl_widget']")
        : $(document).find("div[class='wbdl_widget']");

      if ($bundlerWidget.length) {
        // If Any bundles for this product
        if ($bundlerWidget.find(".radio_select").is(":checked")) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation(); // Stop propagation to prevent AJAX add-to-cart
          addOfferToCart($atcButton, $bundlerWidget);
        } else {
          e.preventDefault();
          e.stopImmediatePropagation(); // Stop propagation to prevent AJAX add-to-cart
          alert(bdlrData.i18n.select_offer_message);
        }
      }
    });

    /* action after custom add to cart button is clicked (case of sales page) */
    $(document).on(
      "click",
      ".custom_add_to_cart_button:not(.disabled)",
      function (e) {
        var $atcBtn = $(this);

        if ($atcBtn.hasClass("loading")) return;

        // Look for the bundler widget near the add to cart form. If there is no add to cart form, look for the widget in the entire page.
        var $bundlerWidget = $atcBtn.parent().find(".wbdl_widget").length
          ? $atcBtn.parent().find(".wbdl_widget")
          : $(document).find("div[class='wbdl_widget']");

        if ($bundlerWidget.length) {
          // If Any bundles for this product
          e.preventDefault();
          if ($bundlerWidget.find(".radio_select").is(":checked")) {
            addOfferToCart($atcBtn, $bundlerWidget);
          } else {
            alert(bdlrData.i18n.select_option_alert);
          }
        }
      }
    );
  });
})();
