(function () {
  const { cart } = Bundler;
  const { addBundleToCart } = cart;

  jQuery(document).ready(function ($) {
    /* action after add bundle to cart button is clicked */
    $(document).on("click", ".bdlr-button", function (e) {
      var $atcBtn = $(this);
      var $bundlerWidget = $atcBtn.closest("div.bdlr_bundle_widget");
      if ($bundlerWidget.length) {
        e.preventDefault();
        addBundleToCart($atcBtn, $bundlerWidget);
      }
    });
  });
})();
